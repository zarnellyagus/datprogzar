import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { DatePipe } from '@angular/common';
import { PolicyService, PolicyInfo, EPolicy, PolicySummary } from '../services/policy.service';

@Component({
  selector: 'app-policy-detail',
  standalone: false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit, OnChanges {
  @Input() policyId!: string;

  policyInfo: PolicyInfo | null = null;
  ePolicies: EPolicy[] = [];
  policySummary: PolicySummary | null = null;

  policyInfoLoading = true;
  ePolicyLoading = true;
  policySummaryLoading = true;

  constructor(
    private policyService: PolicyService,
    private datePipe: DatePipe
  ) {}

  ngOnInit(): void {
    if (this.policyId) this.loadPolicyData();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['policyId'] && !changes['policyId'].firstChange && this.policyId) {
      this.resetState();
      this.loadPolicyData();
    }
  }

  resetState(): void {
    this.policyInfo = null;
    this.ePolicies = [];
    this.policySummary = null;
    this.policyInfoLoading = true;
    this.ePolicyLoading = true;
    this.policySummaryLoading = true;
  }

  loadPolicyData(): void {
    // Load Policy Info
    this.policyService.getPolicyInfo(this.policyId).subscribe({
      next: (data: PolicyInfo) => {
        this.policyInfo = data;
        this.policyInfoLoading = false;
      },
      error: (error) => {
        console.error('Error loading policy info', error);
        this.policyInfo = null;
        this.policyInfoLoading = false;
      }
    });

    // Load E-Policy
    this.policyService.getEPolicy(this.policyId).subscribe({
      next: (data: EPolicy[]) => {
        this.ePolicies = data;
        this.ePolicyLoading = false;
      },
      error: (error) => {
        console.error('Error loading e-policy', error);
        this.ePolicies = [];
        this.ePolicyLoading = false;
      }
    });

    // Load Policy Summary
    this.policyService.getPolicySummary(this.policyId).subscribe({
      next: (data: PolicySummary) => {
        this.policySummary = data;
        this.policySummaryLoading = false;
      },
      error: (error) => {
        console.error('Error loading policy summary', error);
        this.policySummary = null;
        this.policySummaryLoading = false;
      }
    });
  }

  formatDate(date: any): string {
    if (!date) return '-';
    try {
      return this.datePipe.transform(date, 'dd/MM/yyyy') ?? '-';
    } catch {
      return '-';
    }
  }

  getPolicyInfoValue(property: keyof PolicyInfo): string {
    if (!this.policyInfo) return '-';
    const value = this.policyInfo[property];
    if (value === null || value === undefined || value === '') return '-';
    return String(value);
  }

  getPolicyInfoDateValue(property: keyof PolicyInfo): string {
    if (!this.policyInfo) return '-';
    return this.formatDate(this.policyInfo[property]);
  }

  getPolicySummaryValue(property: keyof PolicySummary): string {
    if (!this.policySummary) return '-';
    const value = this.policySummary[property];
    if (value === null || value === undefined || value === '') return '-';
    return String(value);
  }

  getPolicySummaryDateValue(property: keyof PolicySummary): string {
    if (!this.policySummary) return '-';
    return this.formatDate(this.policySummary[property]);
  }

  getEPolicyValue(epolicy: EPolicy | null, property: keyof EPolicy): string {
    if (!epolicy) return '-';
    const value = epolicy[property];
    if (value === null || value === undefined || value === '') return '-';
    return String(value);
  }

  getEPolicyDateValue(epolicy: EPolicy | null, property: keyof EPolicy): string {
    if (!epolicy) return '-';
    return this.formatDate(epolicy[property]);
  }
}
