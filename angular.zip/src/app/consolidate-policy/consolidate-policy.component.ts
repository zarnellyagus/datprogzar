import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { PolicyService, ConsolidatePolicy } from '../services/policy.service';

@Component({
  selector: 'app-consolidate-policy',
  standalone: false,
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
export class ConsolidatePolicyComponent implements OnInit {
  searchForm!: FormGroup;
  policies: ConsolidatePolicy[] = [];
  currentPage = 1;
  pageSize = 10;
  totalCount = 0;
  totalPages = 0;
  isLoading = false;

  selectedPolicyId: string | null = null; // ← STATE UNTUK DETAIL

  constructor(
    private formBuilder: FormBuilder,
    private policyService: PolicyService,
    private datePipe: DatePipe
  ) {
    this.searchForm = this.formBuilder.group({
      policyId: [''],
      appNo: ['']
    });
  }

  trackByPolicyId(index: number, item: any): any {
    return item.policyID ?? index;
  }

  ngOnInit(): void {
    console.log('ConsolidatePolicy loaded');
    this.loadData();
  }

  loadData(): void {
    this.isLoading = true;
    const formValues = this.searchForm.value;
    this.policyService.getConsolidatePolicy(
      formValues.policyId || undefined,
      formValues.appNo || undefined,
      this.currentPage,
      this.pageSize
    ).subscribe({
      next: (response) => {
        this.policies = response.data;
        this.totalCount = response.totalCount ?? 0;
        this.totalPages = response.totalPages ?? Math.ceil((response.totalCount ?? 0) / this.pageSize);
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading data', error);
        this.policies = [];
        this.totalCount = 0;
        this.totalPages = 0;
        this.isLoading = false;
      }
    });
  }

  onSearch(): void {
    this.currentPage = 1;
    this.loadData();
  }

  onReset(): void {
    this.searchForm.reset();
    this.currentPage = 1;
    this.loadData();
  }

  onPageSizeChange(): void {
    this.currentPage = 1;
    this.loadData();
  }

  getPageNumbers(): number[] {
    if (this.totalPages <= 1) return [];
    const pages: number[] = [];
    const maxVisible = 5;
    let startPage = Math.max(1, this.currentPage - Math.floor(maxVisible / 2));
    let endPage = Math.min(this.totalPages, startPage + maxVisible - 1);
    if (endPage - startPage + 1 < maxVisible) {
      startPage = Math.max(1, endPage - maxVisible + 1);
    }
    for (let i = startPage; i <= endPage; i++) pages.push(i);
    return pages;
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages || page === this.currentPage) return;
    this.currentPage = page;
    this.loadData();
  }

  viewPolicyDetail(policyId: string): void {
    this.selectedPolicyId = policyId; // ← TAMPILKAN DETAIL INLINE
  }

  backToList(): void {
    this.selectedPolicyId = null; // ← KEMBALI KE LIST
  }

  formatDate(date: any): string {
    if (!date) return '-';
    return this.datePipe.transform(date, 'dd/MM/yyyy') ?? '-';
  }
}
