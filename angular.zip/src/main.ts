import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';

console.log('Starting Angular application...');

platformBrowserDynamic()
  .bootstrapModule(AppModule)
  .catch(err => {
    console.error('Error starting application:', err);
  });
