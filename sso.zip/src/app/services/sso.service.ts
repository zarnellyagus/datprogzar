import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

export interface SsoConfig {
  entityId: string;
  signOnUrl: string;
  logoutUrl: string;
  returnUrl: string;
}

export interface SsoTokenResponse {
  success: boolean;
  token: string;
  refreshToken?: string;
  username: string;
  companyID: string;
  message?: string;
}

@Injectable({
  providedIn: 'root'
})
export class SsoService {

  private readonly SSO_CONFIG: SsoConfig = {
    entityId: 'https://istaruat.id.sunlife:4490/',
    signOnUrl: 'https://login.microsoftonline.com/415bb08f-1a20-4fbe-9b57-313be7050945/saml2',
    logoutUrl: 'https://login.microsoftonline.com/415bb08f-1a20-4fbe-9b57-313be7050945/saml2',
    returnUrl: 'https://istaruat.id.sunlife:4491/api/auth-service/sso-callback'
  };

  // URL backend untuk initiate SSO (backend yang generate SAML AuthnRequest)
  private readonly SSO_INITIATE_URL = 'https://istaruat.id.sunlife:4491/api/auth-service/sso-initiate';

  constructor(private http: HttpClient, private router: Router) {}

  /**
   * Redirect user ke Azure AD via backend-initiated SSO
   * Backend akan generate SAML AuthnRequest lalu redirect ke Azure AD
   */
  initiateSSO(): void {
    // Simpan current URL untuk redirect setelah login
    const returnPath = window.location.pathname || '/dashboard';
    sessionStorage.setItem('sso_return_path', returnPath);

    // Redirect ke backend SSO initiator - backend handle SAML AuthnRequest
    window.location.href = `${this.SSO_INITIATE_URL}?returnUrl=${encodeURIComponent(window.location.origin + '/sso-callback')}`;
  }

  /**
   * Alternative: langsung redirect ke Azure AD SignOnUrl
   * Gunakan jika backend sudah setup SP metadata di Azure AD
   */
  initiateSSODirect(): void {
    const returnPath = window.location.pathname || '/dashboard';
    sessionStorage.setItem('sso_return_path', returnPath);

    // Redirect langsung ke Azure AD SAML endpoint
    window.location.href = this.SSO_CONFIG.signOnUrl;
  }

  /**
   * Handle callback setelah SSO - exchange token dari backend
   */
  handleSsoCallback(token: string, companyID?: string): Observable<SsoTokenResponse> {
    return this.http.post<SsoTokenResponse>(
      'https://istaruat.id.sunlife:4491/api/auth-service/sso-token-exchange',
      { token, companyID }
    );
  }

  /**
   * Logout SSO - redirect ke Azure AD logout
   */
  logout(): void {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_info');
    sessionStorage.clear();
    window.location.href = this.SSO_CONFIG.logoutUrl;
  }

  getSsoConfig(): SsoConfig {
    return this.SSO_CONFIG;
  }
}